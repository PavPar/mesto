# Проект 4: Место
## Особенности проекта 

* Работа с макетом Figma
* Адаптивный интерфейс да 320px
* Интерактивная страница с возможностью изменения заголовка
* Popup окно

## Ссылки
* [Ссылка на макет в Figma](https://www.figma.com/file/StZjf8HnoeLdiXS7dYrLAh/JavaScript.-Sprint-4)
* [Ссылка на проект на GH](https://pavpar.github.io/mesto/index.html)